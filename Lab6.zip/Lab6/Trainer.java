package Lab6;

import java.util.HashSet;

public class Trainer {
    private HashSet<Player> playersTrained = new HashSet<>();

    private void trainOneDay(Player player) {
        double presentStrength = player.getKickStrength();
        presentStrength += presentStrength/10;
        player.setKickStrength(presentStrength);
    }

    public void train(int days, Player player) {
        playersTrained.add(player);

        for(int counter = 0; counter < days; counter++) {
            trainOneDay(player);
        }
    }

    public int numberOfTrainedPlayers() {
        return playersTrained.size();
    }

    public Trainer() {

    }

}
