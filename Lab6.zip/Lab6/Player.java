package Lab6;

public class Player {
    private double kickStrength;

    public void Kick(Ball ball) {
        double metersTraveled = ball.getMetersTraveled();
        metersTraveled += kickStrength * 5;
        ball.setMetersTraveled(metersTraveled);
        int timesKicked = ball.getTimesKicked();
        ball.setTimesKicked(timesKicked + 1);
    }

    public void setKickStrength(double kickStrength) {
        this.kickStrength = kickStrength;
    }

    public double getKickStrength() {
        return kickStrength;
    }

    public Player(double kickStrength) {
        this.kickStrength = kickStrength;
    }
}
