package Lab6;

public class Ball {
    private double metersTraveled;
    private int timesKicked;

    public String status() {
        return "Times kicked:" + timesKicked + " Traveled distance: " + metersTraveled;
    }

    public void setMetersTraveled(double metersTraveled) {
        this.metersTraveled = metersTraveled;
    }

    public void  setTimesKicked(int timesKicked){
        this.timesKicked = timesKicked;
    }

    public double getMetersTraveled() {
        return metersTraveled;
    }

    public int getTimesKicked(){
        return timesKicked;
    }

    public Ball(){

    }
}
