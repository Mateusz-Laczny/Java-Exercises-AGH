package Lab6;

public class TestMain {
    public static void main(String[] args) {
        Player testPlayer = new Player(4.5);
        Trainer testTrainer = new Trainer();
        Ball testBall1 = new Ball();
        Ball testBall2 = new Ball();
        Player testPlayer2 = new Player(2.1);
        Trainer testTrainer2 = new Trainer();

        System.out.println(testBall1.getTimesKicked());
        System.out.println(testBall1.getMetersTraveled());
        testPlayer.Kick(testBall1);
        System.out.println(testBall1.getTimesKicked());
        System.out.println(testBall1.getMetersTraveled());
        System.out.println();
        System.out.println(testBall2.getMetersTraveled());
        testPlayer2.Kick(testBall2);
        System.out.println(testBall2.getMetersTraveled());
        testTrainer.train(1, testPlayer2);
        testPlayer2.Kick(testBall2);
        System.out.println(testBall2.getMetersTraveled());
        System.out.println(testTrainer.numberOfTrainedPlayers());
        testTrainer.train(1, testPlayer);
        System.out.println(testTrainer.numberOfTrainedPlayers());
        testTrainer2.train(3, testPlayer);
        System.out.println(testTrainer2.numberOfTrainedPlayers());
        System.out.println(testPlayer.getKickStrength());

    }
}
